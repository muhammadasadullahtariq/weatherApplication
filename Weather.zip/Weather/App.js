/**
 open terminal in folder
 run command npm i 
 it will install all the packages 
 than run 
 npx react-native run-android
 it will start your application on android device
 */

import React, {useState, useEffect} from 'react';

//import RNLocation from 'react-native-location';
import * as Location from 'expo-location';
//import Geolocation from 'react-native-geolocation-service'; //this package is use to get location of user
import FlatlistItem from './src/Components/flatListItem'; //it show the item in Flatlist or you can say flatlist item design
import {FlatList, View} from 'react-native';
import setArray from './src/Functions/SetArray'; //it parse and get the usefull data
import WaitingAlert from './src/Components/waitingAlertComponent'; //the alter that shown on screen and say please wait
import SingleButtonAlert from './src/Components/singleButtonAlert';
import HeaderText from './src/Components/headerText';
import {StatusBar} from 'expo-status-bar';
const App = () => {
  const [dataArr, setDataArr] = useState([]);
  const [alertFlag, setAlert] = useState(true);
  const [errorMsg, setErrorMsg] = useState(null);
  const [errorFlag, setErrorFlag] = useState(false);

  //funtion that get the weather data from API
  //after fetching the data it call the SetArray funtion to filter the data
  const getWeaterData = async (long, lati) => {
    var day = new Date();
    //console.error(day.getDay());
    console.log('long', long);
    console.log('long', lati);
    try {
      const response = await fetch(
        'https://api.openweathermap.org/data/2.5/onecall?lat=' +
          lati +
          '&lon=' +
          long +
          '&exclude=current%2Cminutely%2Chourly%2Calert&appid=e51d26c87446d7ff7a35f279f7dc414d',
        {
          method: 'GET',
          headers: {
            'cache-control': 'no-cache',
          },
        },
      )
        .then(response => response.json())
        .then(data => {
          setDataArr(setArray(data));
          setAlert(false);
        })
        .catch(err => {
          //console.error(err);
          setErrorMsg('Some network error occure');
          setErrorFlag(true);
        });
      //console.error(response);
    } catch (error) {
      setErrorMsg('Some network error occure');
      setErrorFlag(true);
      return 'Media not found';
    }
  };

  useEffect(() => {
    (async () => {
      let {status} = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        setErrorFlag(true);
        return;
      }
      let location = await Location.getCurrentPositionAsync({});
      getWeaterData(location.coords.longitude, location.coords.latitude);
      console.log('Location is ', location);
    })();
  });

  //it the design of whole screen
  return (
    <View>
      <StatusBar style="light" backgroundColor="#1692ff" />
      <View
        style={{
          height: 50,
          width: '100%',
          backgroundColor: '#1692ff',
          marginTop: 35,
        }}>
        <HeaderText
          text={'Week Weather'}
          componentStyle={{color: 'white', textAlign: 'center', marginTop: 0}}
        />
      </View>
      <SingleButtonAlert
        visible={errorFlag}
        text={errorMsg}
        onPress={() => setErrorFlag(false)}
      />
      <WaitingAlert visible={alertFlag} />
      <FlatList
        data={dataArr}
        renderItem={items => <FlatlistItem dailyStatus={items.item} />}
      />
    </View>
  );
};

export default App;
